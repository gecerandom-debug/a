package com.example.trail;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.function.Supplier;

public class SettingsScreen extends Screen {
    private int row = 0;

    public SettingsScreen() {
        super(Text.literal("Trail Mod Ayarları"));
    }

    private static String onOff(boolean b) { return b ? "Açık" : "Kapalı"; }

    private void add(int col, Supplier<String> label, Runnable action) {
        int x = col == 0 ? width / 2 - 155 : width / 2 + 5;
        int y = 40 + (row / 2) * 24;
        ButtonWidget[] ref = new ButtonWidget[1];
        ref[0] = ButtonWidget.builder(Text.literal(label.get()), b -> {
            action.run();
            b.setMessage(Text.literal(label.get()));
        }).dimensions(x, y, 150, 20).build();
        addDrawableChild(ref[0]);
        row++;
    }

    @Override
    protected void init() {
        row = 0;
        Config c = Config.I;
        add(0, () -> "İz: " + onOff(c.trail), () -> c.trail = !c.trail);
        add(1, () -> "Efekt: " + TrailMod.NAMES[c.effect], () -> c.effect = (c.effect + 1) % TrailMod.NAMES.length);
        add(0, () -> "Yoğunluk: " + c.amount, () -> c.amount = c.amount % 8 + 1);
        add(1, () -> "Hedef bilgisi: " + onOff(c.targetHud), () -> c.targetHud = !c.targetHud);
        add(0, () -> "Kilit işareti: " + onOff(c.lockMarker), () -> c.lockMarker = !c.lockMarker);
        add(1, () -> "Müzik göstergesi: " + onOff(c.musicHud), () -> c.musicHud = !c.musicHud);
        add(0, () -> "Müzik süresi: " + (c.musicSeconds == 0 ? "Hep" : c.musicSeconds + " sn"),
            () -> c.musicSeconds = switch (c.musicSeconds) { case 5 -> 10; case 10 -> 30; case 30 -> 0; default -> 5; });
        add(1, () -> "Müzik yeri: " + new String[]{"Sol üst", "Sağ üst", "Sol alt", "Sağ alt"}[c.musicCorner],
            () -> c.musicCorner = (c.musicCorner + 1) % 4);
        add(0, () -> "Silah slotu: " + c.weaponSlot, () -> c.weaponSlot = c.weaponSlot % 9 + 1);
        add(1, () -> "Fişek slotu: " + c.fireworkSlot, () -> c.fireworkSlot = c.fireworkSlot % 9 + 1);

        add(0, () -> "Koordinat/FPS: " + onOff(c.coordsHud), () -> c.coordsHud = !c.coordsHud);
        add(1, () -> "Hep koş: " + onOff(c.autoSprint), () -> c.autoSprint = !c.autoSprint);

        add(0, () -> "Oto vuruş (moblar): " + onOff(c.autoAttack), () -> c.autoAttack = !c.autoAttack);
        add(1, () -> "Vuruş gecikmesi: " + c.attackDelay + " tick", () -> c.attackDelay = c.attackDelay % 40 + 1);
        add(0, () -> "Cooldown bekle: " + onOff(c.waitCooldown), () -> c.waitCooldown = !c.waitCooldown);
        add(1, () -> "Sadece düşman mob: " + onOff(c.hostileOnly), () -> c.hostileOnly = !c.hostileOnly);

        add(0, () -> "Cooldown göstergesi: " + onOff(c.cooldownHud), () -> c.cooldownHud = !c.cooldownHud);
        add(1, () -> "Sadece hedefteyken: " + onOff(c.cooldownOnlyTarget), () -> c.cooldownOnlyTarget = !c.cooldownOnlyTarget);

        addDrawableChild(ButtonWidget.builder(Text.literal("Bitti"), b -> close())
            .dimensions(width / 2 - 155, 40 + 9 * 24 + 12, 150, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Görseller / HUD →"), b -> client.setScreen(new VisualsScreen(this)))
            .dimensions(width / 2 + 5, 40 + 9 * 24 + 12, 150, 20).build());
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 16, 0xFFFFFFFF);
    }

    @Override
    public void close() {
        Config.save();
        super.close();
    }
}
