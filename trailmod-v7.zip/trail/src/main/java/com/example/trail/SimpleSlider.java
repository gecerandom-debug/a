package com.example.trail;

import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

import java.util.function.IntConsumer;

public class SimpleSlider extends SliderWidget {
    private final String label;
    private final int min, max;
    private final IntConsumer setter;

    public SimpleSlider(int x, int y, int w, int h, String label, int min, int max, int val, IntConsumer setter) {
        super(x, y, w, h, Text.empty(), (val - min) / (double) (max - min));
        this.label = label;
        this.min = min;
        this.max = max;
        this.setter = setter;
        updateMessage();
    }

    private int current() { return min + (int) Math.round(this.value * (max - min)); }

    @Override
    protected void updateMessage() {
        setMessage(Text.literal(label + ": " + current()));
    }

    @Override
    protected void applyValue() {
        setter.accept(current());
    }
}
