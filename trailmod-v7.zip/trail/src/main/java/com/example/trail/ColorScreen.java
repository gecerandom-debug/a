package com.example.trail;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class ColorScreen extends Screen {
    private final Screen parent;

    public ColorScreen(Screen parent) {
        super(Text.literal("Renkler"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        Config c = Config.I;
        int lx = width / 2 - 154, rx = width / 2 + 4, y = 56;
        String[] ch = {"Kırmızı", "Yeşil", "Mavi"};
        int[] shift = {16, 8, 0};
        for (int i = 0; i < 3; i++) {
            final int sh = shift[i];
            addDrawableChild(new SimpleSlider(lx, y + i * 22, 150, 20, "Ana " + ch[i], 0, 255,
                (c.colorA >> sh) & 255, v -> c.colorA = (c.colorA & ~(255 << sh)) | (v << sh)));
            addDrawableChild(new SimpleSlider(rx, y + i * 22, 150, 20, "İkincil " + ch[i], 0, 255,
                (c.colorB >> sh) & 255, v -> c.colorB = (c.colorB & ~(255 << sh)) | (v << sh)));
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("Geri"), b -> close())
            .dimensions(width / 2 - 75, y + 3 * 22 + 40, 150, 20).build());
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 14, 0xFFFFFFFF);
        Config c = Config.I;
        int y = 56 + 3 * 22 + 8;
        ctx.fill(width / 2 - 154, y, width / 2 - 4, y + 20, 0xFF000000 | c.colorA);
        ctx.fill(width / 2 + 4, y, width / 2 + 154, y + 20, 0xFF000000 | c.colorB);
        for (int i = 0; i < 40; i++) {
            ctx.fill(width / 2 - 154 + i * 308 / 40, 32, width / 2 - 154 + (i + 1) * 308 / 40, 44,
                0xFF000000 | Theme.color(i / 40f));
        }
    }

    @Override
    public void close() {
        Config.save();
        client.setScreen(parent);
    }
}
