package com.example.trail;

import net.minecraft.client.sound.SoundInstance;
import net.minecraft.sound.SoundCategory;

import java.util.Map;

public class MusicInfo {
    public static String name = null;
    public static long startMs = 0;

    private static final Map<String, String> DISCS = Map.ofEntries(
        Map.entry("13", "C418 - 13"), Map.entry("cat", "C418 - cat"),
        Map.entry("blocks", "C418 - blocks"), Map.entry("chirp", "C418 - chirp"),
        Map.entry("far", "C418 - far"), Map.entry("mall", "C418 - mall"),
        Map.entry("mellohi", "C418 - mellohi"), Map.entry("stal", "C418 - stal"),
        Map.entry("strad", "C418 - strad"), Map.entry("ward", "C418 - ward"),
        Map.entry("11", "C418 - 11"), Map.entry("wait", "C418 - wait"),
        Map.entry("pigstep", "Lena Raine - Pigstep"), Map.entry("otherside", "Lena Raine - otherside"),
        Map.entry("5", "Samuel Åberg - 5"), Map.entry("relic", "Aaron Cherof - Relic"),
        Map.entry("creator", "Lena Raine - Creator"), Map.entry("creator_music_box", "Lena Raine - Creator (Music Box)"),
        Map.entry("precipice", "Aaron Cherof - Precipice")
    );

    public static void onSound(SoundInstance s) {
        SoundCategory c = s.getCategory();
        if (c != SoundCategory.MUSIC && c != SoundCategory.RECORDS) return;
        String path = s.getId().getPath();
        String n;
        if (path.startsWith("music_disc.")) {
            String key = path.substring("music_disc.".length());
            n = "Plak: " + DISCS.getOrDefault(key, key);
        } else if (path.contains("menu")) n = "Menü müziği";
        else if (path.contains("creative")) n = "Yaratıcı mod müziği";
        else if (path.contains("nether")) n = "Nether müziği";
        else if (path.contains("end")) n = "End müziği";
        else if (path.contains("under_water")) n = "Su altı müziği";
        else n = "Oyun müziği";
        name = n;
        startMs = System.currentTimeMillis();
    }
}
