package com.example.trail;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.function.Supplier;

public class VisualsScreen extends Screen {
    private final Screen parent;

    public VisualsScreen(Screen parent) {
        super(Text.literal("Görseller / HUD"));
        this.parent = parent;
    }

    private void btn(int col, int row, int span, Supplier<String> label, Runnable action) {
        int x = width / 2 - 154 + col * 104;
        int y = 32 + row * 22;
        addDrawableChild(ButtonWidget.builder(Text.literal(label.get()), b -> {
            action.run();
            b.setMessage(Text.literal(label.get()));
        }).dimensions(x, y, 100 + (span - 1) * 104, 20).build());
    }

    private static String onOff(boolean b) { return b ? "Açık" : "Kapalı"; }

    @Override
    protected void init() {
        Config c = Config.I;
        for (int i = 0; i < HudElements.IDS.length; i++) {
            final int k = i;
            btn(i % 3, i / 3, 1,
                () -> (HudElements.elem(HudElements.IDS[k]).on ? "[+] " : "[ ] ") + HudElements.NAMES[k],
                () -> { var e = HudElements.elem(HudElements.IDS[k]); e.on = !e.on; });
        }
        int r = (HudElements.IDS.length + 2) / 3;
        btn(0, r, 1, () -> "Tema: " + new String[]{"Sabit", "Rainbow", "Gradient"}[c.themeMode],
            () -> c.themeMode = (c.themeMode + 1) % 3);
        btn(1, r, 1, () -> "Vuruş parçacığı: " + onOff(c.hitParticles), () -> c.hitParticles = !c.hitParticles);
        btn(2, r, 1, () -> "Efekt: " + TrailMod.NAMES[c.hitEffect % TrailMod.NAMES.length],
            () -> c.hitEffect = (c.hitEffect + 1) % TrailMod.NAMES.length);
        r++;
        btn(0, r, 1, () -> "China Hat: " + onOff(c.chinaHat), () -> c.chinaHat = !c.chinaHat);
        btn(1, r, 1, () -> "Renkler...", () -> client.setScreen(new ColorScreen(this)));
        btn(2, r, 1, () -> "HUD düzenle", () -> client.setScreen(new HudEditScreen(this)));
        r++;
        addDrawableChild(new SimpleSlider(width / 2 - 154, 32 + r * 22, 308, 20, "Panel opaklığı", 0, 255,
            c.opacity, v -> c.opacity = v));
        r++;
        addDrawableChild(ButtonWidget.builder(Text.literal("Geri"), b -> close())
            .dimensions(width / 2 - 75, 32 + r * 22 + 6, 150, 20).build());
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 14, 0xFFFFFFFF);
    }

    @Override
    public void close() {
        Config.save();
        client.setScreen(parent);
    }
}
