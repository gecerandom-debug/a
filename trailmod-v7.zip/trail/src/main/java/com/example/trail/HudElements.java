package com.example.trail;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HudElements {
    public static final String[] IDS = {"ping", "cps", "speed", "time", "armor", "effects",
        "modules", "keys", "combo", "damage", "totems", "fireworks"};
    public static final String[] NAMES = {"Ping", "CPS", "Hız", "Zaman", "Zırh", "Efektler",
        "Modüller", "Tuşlar", "Combo", "Hasar", "Totem", "Fişek"};
    private static final float[][] DEF_POS = {
        {0.01f, 0.20f}, {0.01f, 0.26f}, {0.01f, 0.32f}, {0.01f, 0.38f}, {0.01f, 0.46f}, {0.80f, 0.30f},
        {0.88f, 0.55f}, {0.45f, 0.72f}, {0.01f, 0.60f}, {0.60f, 0.45f}, {0.01f, 0.68f}, {0.01f, 0.74f}
    };
    private static final boolean[] DEF_ON = {true, true, false, false, false, false,
        false, true, true, false, false, false};

    public static final Map<String, float[]> bounds = new HashMap<>();
    private static final Map<String, Float> alpha = new HashMap<>();

    private static final ArrayDeque<Long> lmb = new ArrayDeque<>(), rmb = new ArrayDeque<>();
    private static boolean prevAtk, prevUse;
    private static int hits, combo, ticks;
    private static long lastHit, dealtT, takenT;
    private static Vec3d lastPos;
    private static double speed;
    private static float dealt, taken, selfHp = -1f, dmgTargetHp;
    private static int dmgTargetId = -1;

    public static Config.Elem elem(String id) {
        Config.Elem e = Config.I.hud.get(id);
        if (e == null) {
            int i = indexOf(id);
            e = new Config.Elem(DEF_ON[i], DEF_POS[i][0], DEF_POS[i][1]);
            Config.I.hud.put(id, e);
        }
        return e;
    }

    private static int indexOf(String id) {
        for (int i = 0; i < IDS.length; i++) if (IDS[i].equals(id)) return i;
        return 0;
    }

    // ---------------- tick ----------------
    public static void tick(MinecraftClient mc) {
        var p = mc.player;
        if (p == null || mc.world == null) return;
        ticks++;
        long now = System.currentTimeMillis();
        Config c = Config.I;

        boolean atk = mc.options.attackKey.isPressed(), use = mc.options.useKey.isPressed();
        if (atk && !prevAtk && mc.currentScreen == null) {
            lmb.add(now);
            if (mc.targetedEntity instanceof LivingEntity le && le.isAlive()) {
                hits++; combo++; lastHit = now;
                if (c.hitParticles) hitFx(mc, le);
            }
        }
        if (use && !prevUse && mc.currentScreen == null) rmb.add(now);
        prevAtk = atk; prevUse = use;
        while (!lmb.isEmpty() && now - lmb.peekFirst() > 1000) lmb.pollFirst();
        while (!rmb.isEmpty() && now - rmb.peekFirst() > 1000) rmb.pollFirst();
        if (combo > 0 && now - lastHit > 3000) combo = 0;

        float hp = p.getHealth();
        if (selfHp >= 0 && hp < selfHp) { taken = selfHp - hp; takenT = now; combo = 0; }
        selfHp = hp;

        LivingEntity t = Hud.currentTarget(mc);
        if (t != null) {
            if (t.getId() == dmgTargetId && t.getHealth() < dmgTargetHp) {
                dealt = dmgTargetHp - t.getHealth(); dealtT = now;
            }
            dmgTargetId = t.getId(); dmgTargetHp = t.getHealth();
        } else dmgTargetId = -1;

        Vec3d pos = p.getPos();
        if (lastPos != null) {
            double dx = pos.x - lastPos.x, dz = pos.z - lastPos.z;
            speed = speed * 0.8 + Math.sqrt(dx * dx + dz * dz) * 20.0 * 0.2;
        }
        lastPos = pos;

        if (c.chinaHat && ticks % 2 == 0 && !mc.options.getPerspective().isFirstPerson()) {
            double cy = p.getY() + p.getHeight() + 0.2;
            for (int i = 0; i < 8; i++) {
                double a = ticks * 0.12 + i * Math.PI / 4.0;
                mc.world.addParticle(ParticleTypes.END_ROD,
                    p.getX() + Math.cos(a) * 0.45, cy, p.getZ() + Math.sin(a) * 0.45, 0, 0, 0);
            }
        }
    }

    private static void hitFx(MinecraftClient mc, LivingEntity le) {
        ParticleEffect e = TrailMod.EFFECTS[Config.I.hitEffect % TrailMod.EFFECTS.length];
        for (int i = 0; i < 10; i++) {
            mc.world.addParticle(e,
                le.getX() + (Math.random() - 0.5) * 0.6,
                le.getY() + le.getHeight() * 0.5 + (Math.random() - 0.5) * 0.6,
                le.getZ() + (Math.random() - 0.5) * 0.6,
                (Math.random() - 0.5) * 0.2, Math.random() * 0.15, (Math.random() - 0.5) * 0.2);
        }
    }

    // ---------------- içerik ----------------
    private static List<String> lines(String id, boolean edit) {
        MinecraftClient mc = MinecraftClient.getInstance();
        var p = mc.player;
        List<String> l = new ArrayList<>();
        long now = System.currentTimeMillis();
        switch (id) {
            case "ping" -> {
                var nh = mc.getNetworkHandler();
                var pe = nh == null ? null : nh.getPlayerListEntry(p.getUuid());
                l.add("Ping: " + (pe == null ? 0 : pe.getLatency()) + " ms");
            }
            case "cps" -> l.add("CPS: " + lmb.size() + " | " + rmb.size());
            case "speed" -> l.add(String.format("Hız: %.1f b/s", speed));
            case "time" -> {
                int sec = ticks / 20;
                l.add(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")));
                l.add(String.format("Oyun: %02d:%02d", sec / 60, sec % 60));
            }
            case "armor" -> {
                String[] names = {"Kask", "Zırh", "Pantolon", "Bot", "El"};
                EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS,
                    EquipmentSlot.FEET, EquipmentSlot.MAINHAND};
                for (int i = 0; i < slots.length; i++) {
                    ItemStack st = p.getEquippedStack(slots[i]);
                    if (!st.isEmpty() && st.isDamageable()) {
                        l.add(names[i] + ": " + (st.getMaxDamage() - st.getDamage()) + "/" + st.getMaxDamage());
                    }
                }
            }
            case "effects" -> {
                for (StatusEffectInstance ef : p.getStatusEffects()) {
                    String time = ef.isInfinite() ? "∞"
                        : String.format("%d:%02d", ef.getDuration() / 1200, (ef.getDuration() / 20) % 60);
                    l.add(ef.getEffectType().value().getName().getString() + " " + (ef.getAmplifier() + 1) + " " + time);
                }
            }
            case "modules" -> {
                Config c = Config.I;
                if (c.trail) l.add("İz");
                if (c.targetHud) l.add("Hedef bilgisi");
                if (c.lockMarker && Hud.lockedId != -1) l.add("Kilit");
                if (c.musicHud) l.add("Müzik");
                if (c.autoSprint) l.add("Hep koş");
                if (c.autoAttack) l.add("Oto vuruş (mob)");
                if (c.cooldownHud) l.add("Cooldown");
                if (c.hitParticles) l.add("Vuruş parçacığı");
                if (c.chinaHat) l.add("China Hat");
            }
            case "keys" -> l.add("keys");
            case "combo" -> { l.add("Combo: " + combo); l.add("Vuruş: " + hits); }
            case "damage" -> {
                if (now - dealtT < 3000) l.add(String.format("Verdiğin: -%.1f", dealt));
                if (now - takenT < 3000) l.add(String.format("Aldığın: -%.1f", taken));
            }
            case "totems" -> l.add("Totem: " + count(p, Items.TOTEM_OF_UNDYING));
            case "fireworks" -> l.add("Fişek: " + count(p, Items.FIREWORK_ROCKET) + "  [" + Config.I.fireworkSlot + "]");
            default -> {}
        }
        if (edit && l.isEmpty()) l.add(NAMES[indexOf(id)]);
        return l;
    }

    private static int count(net.minecraft.entity.player.PlayerEntity p, net.minecraft.item.Item item) {
        int n = 0;
        for (int i = 0; i < p.getInventory().size(); i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (s.isOf(item)) n += s.getCount();
        }
        return n;
    }

    // ---------------- çizim ----------------
    public static void renderAll(DrawContext ctx, boolean edit) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        TextRenderer tr = mc.textRenderer;
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();

        for (int i = 0; i < IDS.length; i++) {
            String id = IDS[i];
            Config.Elem e = elem(id);
            List<String> lines = (e.on || edit) ? lines(id, edit) : List.of();
            boolean want = (e.on && !lines.isEmpty()) || edit;
            float target = want ? (e.on || !edit ? 1f : 0.35f) : 0f;
            float a = alpha.getOrDefault(id, 0f);
            a += (target - a) * 0.2f;
            alpha.put(id, a);
            if (a < 0.05f || lines.isEmpty()) { bounds.remove(id); continue; }

            boolean keys = id.equals("keys");
            int bw, bh;
            if (keys) { bw = 46; bh = 46; }
            else {
                int tw = 0;
                for (String s : lines) tw = Math.max(tw, tr.getWidth(s));
                bw = tw + 9; bh = lines.size() * 10 + 4;
            }
            float px = e.x * w, py = e.y * h;
            bounds.put(id, new float[]{px, py, bw * e.scale, bh * e.scale});

            int A = (int) (a * 255);
            var m = ctx.getMatrices();
            m.push();
            m.translate(px, py, 0);
            m.scale(e.scale, e.scale, 1f);
            if (keys) drawKeys(ctx, mc, tr, A, i);
            else {
                ctx.fill(0, 0, bw, bh, ((int) (Config.I.opacity * a)) << 24);
                ctx.fill(0, 0, 2, bh, (A << 24) | Theme.color(i * 0.08f));
                for (int j = 0; j < lines.size(); j++) {
                    ctx.drawTextWithShadow(tr, lines.get(j), 6, 3 + j * 10, (A << 24) | 0xFFFFFF);
                }
            }
            if (edit) ctx.drawBorder(0, 0, bw, bh, 0xFFFFFFFF);
            m.pop();
        }
    }

    private static void drawKeys(DrawContext ctx, MinecraftClient mc, TextRenderer tr, int A, int idx) {
        var o = mc.options;
        key(ctx, tr, 16, 0, 14, 14, "W", o.forwardKey.isPressed(), A, idx);
        key(ctx, tr, 0, 16, 14, 14, "A", o.leftKey.isPressed(), A, idx);
        key(ctx, tr, 16, 16, 14, 14, "S", o.backKey.isPressed(), A, idx);
        key(ctx, tr, 32, 16, 14, 14, "D", o.rightKey.isPressed(), A, idx);
        key(ctx, tr, 0, 32, 22, 14, "L", o.attackKey.isPressed(), A, idx);
        key(ctx, tr, 24, 32, 22, 14, "R", o.useKey.isPressed(), A, idx);
    }

    private static void key(DrawContext ctx, TextRenderer tr, int x, int y, int w, int h,
                            String label, boolean down, int A, int idx) {
        int bg = down ? ((Math.min(A, 190) << 24) | Theme.color(idx * 0.08f))
                      : (((int) (Config.I.opacity * (A / 255f))) << 24);
        ctx.fill(x, y, x + w, y + h, bg);
        ctx.drawCenteredTextWithShadow(tr, label, x + w / 2, y + (h - 8) / 2, (A << 24) | 0xFFFFFF);
    }
}
