package com.example.trail;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;

public class Hud {
    public static int lockedId = -1;
    private static float animRatio = 1f;
    private static int animId = -2;

    public static LivingEntity currentTarget(MinecraftClient mc) {
        if (mc.world == null) return null;
        if (lockedId != -1) {
            Entity e = mc.world.getEntityById(lockedId);
            if (e instanceof LivingEntity le && le.isAlive()) return le;
            lockedId = -1;
        }
        if (mc.targetedEntity instanceof LivingEntity le) return le;
        return null;
    }

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;
        TextRenderer tr = mc.textRenderer;
        int w = ctx.getScaledWindowWidth();
        int h = ctx.getScaledWindowHeight();
        Config c = Config.I;

        if (c.targetHud) {
            LivingEntity t = currentTarget(mc);
            if (t != null) {
                boolean locked = t.getId() == lockedId;
                int pw = 170, ph = 38;
                int x = w / 2 - pw / 2, y = 8;
                ctx.fill(x, y, x + pw, y + ph, 0xAA000000);
                ctx.fill(x, y, x + 2, y + ph, locked ? 0xFFFF5555 : 0xFF55FF55);
                String name = (locked ? "[KİLİT] " : "") + t.getName().getString();
                ctx.drawTextWithShadow(tr, name, x + 6, y + 4, 0xFFFFFFFF);
                float hp = t.getHealth(), max = Math.max(1f, t.getMaxHealth());
                float real = MathHelper.clamp(hp / max, 0f, 1f);
                if (animId != t.getId()) { animRatio = real; animId = t.getId(); }
                animRatio += (real - animRatio) * 0.15f;
                float ratio = animRatio;
                int barW = pw - 12;
                int col = ratio > 0.6f ? 0xFF55FF55 : ratio > 0.3f ? 0xFFFFAA00 : 0xFFFF3333;
                ctx.fill(x + 6, y + 15, x + 6 + barW, y + 21, 0xFF333333);
                ctx.fill(x + 6, y + 15, x + 6 + (int) (barW * ratio), y + 21, col);
                String info = String.format("HP %.1f/%.0f", hp, max);
                if (t.getAbsorptionAmount() > 0) info += String.format(" +%.0f", t.getAbsorptionAmount());
                info += "  Zırh " + t.getArmor() + "  " + String.format("%.1f m", mc.player.distanceTo(t));
                ctx.drawTextWithShadow(tr, info, x + 6, y + 25, 0xFFDDDDDD);

                if (locked) {
                    double dx = t.getX() - mc.player.getX(), dz = t.getZ() - mc.player.getZ();
                    float yaw = (float) (MathHelper.atan2(dz, dx) * 180.0 / Math.PI) - 90f;
                    float diff = MathHelper.wrapDegrees(yaw - mc.player.getYaw());
                    String arrow = Math.abs(diff) < 30 ? "↑" : Math.abs(diff) > 150 ? "↓" : diff > 0 ? "→" : "←";
                    ctx.drawCenteredTextWithShadow(tr, arrow, w / 2, y + ph + 4, 0xFFFF5555);
                }
            }
        }

        if (!(mc.currentScreen instanceof HudEditScreen)) HudElements.renderAll(ctx, false);

        if (c.cooldownHud) {
            boolean onTarget = mc.targetedEntity instanceof LivingEntity;
            if (onTarget || !c.cooldownOnlyTarget) {
                float prog = MathHelper.clamp(mc.player.getAttackCooldownProgress(0f), 0f, 1f);
                boolean ready = prog >= 1.0f;
                int bw = 40, bx = w / 2 - bw / 2, by = h / 2 + 14;
                ctx.fill(bx - 1, by - 1, bx + bw + 1, by + 5, 0xAA000000);
                int col = ready ? 0xFF55FF55 : prog > 0.6f ? 0xFFFFAA00 : 0xFFFF5555;
                ctx.fill(bx, by, bx + (int) (bw * prog), by + 4, col);
                if (ready && onTarget) {
                    ctx.drawCenteredTextWithShadow(tr, "HAZIR", w / 2, by + 8, 0xFF55FF55);
                }
            }
        }

        if (c.coordsHud) {
            String pos = String.format("XYZ %.0f / %.0f / %.0f", mc.player.getX(), mc.player.getY(), mc.player.getZ());
            String dir = mc.player.getHorizontalFacing().asString().toUpperCase();
            String line = pos + "  " + dir + "  " + mc.getCurrentFps() + " FPS";
            int tw = tr.getWidth(line) + 12;
            ctx.fill(6, 26, 6 + tw, 42, 0xAA000000);
            ctx.drawTextWithShadow(tr, line, 12, 30, 0xFFFFFFFF);
        }

        if (c.musicHud && MusicInfo.name != null) {
            long age = System.currentTimeMillis() - MusicInfo.startMs;
            if (c.musicSeconds == 0 || age < c.musicSeconds * 1000L) {
                String text = "♪ " + MusicInfo.name;
                int tw = tr.getWidth(text) + 12;
                int x = (c.musicCorner % 2 == 0) ? 6 : w - tw - 6;
                int y = (c.musicCorner < 2) ? 6 : h - 46;
                if (c.musicCorner < 2 && c.targetHud) y = 6;
                ctx.fill(x, y, x + tw, y + 16, 0xAA000000);
                ctx.drawTextWithShadow(tr, text, x + 6, y + 4, 0xFFFFD27F);
            }
        }
    }
}
