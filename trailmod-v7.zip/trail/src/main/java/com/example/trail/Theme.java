package com.example.trail;

public class Theme {
    /** off: öğeler arası renk kayması (0..1). Dönen değer 0xRRGGBB. */
    public static int color(float off) {
        Config c = Config.I;
        float t = (System.currentTimeMillis() % 10000L) / 10000f;
        switch (c.themeMode) {
            case 1:
                return java.awt.Color.HSBtoRGB((t + off) % 1f, 0.7f, 1f) & 0xFFFFFF;
            case 2: {
                float k = (float) (Math.sin((t * 2f + off) * Math.PI * 2.0) * 0.5 + 0.5);
                return lerp(c.colorA, c.colorB, k);
            }
            default:
                return c.colorA & 0xFFFFFF;
        }
    }

    public static int lerp(int a, int b, float k) {
        int r = (int) (((a >> 16) & 255) * (1 - k) + ((b >> 16) & 255) * k);
        int g = (int) (((a >> 8) & 255) * (1 - k) + ((b >> 8) & 255) * k);
        int bl = (int) ((a & 255) * (1 - k) + (b & 255) * k);
        return (r << 16) | (g << 8) | bl;
    }
}
