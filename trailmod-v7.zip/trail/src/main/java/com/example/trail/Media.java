package com.example.trail;

/** Windows medya tuşlarını gönderir: Spotify, tarayıcıdaki YouTube vb. ne çalıyorsa onu yönetir. */
public class Media {
    public static final int PLAY_PAUSE = 179, NEXT = 176, PREV = 177;

    public static boolean supported() {
        return System.getProperty("os.name", "").toLowerCase().contains("win");
    }

    public static void send(int code) {
        if (!supported()) return;
        new Thread(() -> {
            try {
                new ProcessBuilder("powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command",
                    "(New-Object -ComObject WScript.Shell).SendKeys([char]" + code + ")")
                    .redirectErrorStream(true).start();
            } catch (Exception ignored) {}
        }, "trailmod-media").start();
    }
}
