package com.example.trail;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

public class TrailMod implements ClientModInitializer {
    public static final ParticleEffect[] EFFECTS = {
        ParticleTypes.END_ROD, ParticleTypes.HEART, ParticleTypes.FLAME, ParticleTypes.NOTE,
        ParticleTypes.SOUL_FIRE_FLAME, ParticleTypes.CHERRY_LEAVES, ParticleTypes.ENCHANT,
        ParticleTypes.TOTEM_OF_UNDYING, ParticleTypes.CRIT, ParticleTypes.HAPPY_VILLAGER
    };
    public static final String[] NAMES = {
        "End Rod", "Kalp", "Ateş", "Nota", "Ruh Ateşi", "Kiraz Yaprağı",
        "Büyü", "Totem", "Kritik", "Köylü"
    };

    private KeyBinding keyEffect, keyToggle, keySettings, keyLock, keyFirework, keyPlay, keyNext, keyPrev, keyAttack;
    private int attackTimer = 0;
    private int returnTicks = 0;
    private int tickCount = 0;

    @Override
    public void onInitializeClient() {
        keyEffect = reg("Efekti değiştir", GLFW.GLFW_KEY_V);
        keyToggle = reg("İzi aç/kapat", GLFW.GLFW_KEY_B);
        keySettings = reg("Ayar menüsü", GLFW.GLFW_KEY_G);
        keyLock = reg("Hedefe kilitlen / bırak", GLFW.GLFW_KEY_R);
        keyFirework = reg("Havai fişek kombosu", GLFW.GLFW_KEY_H);
        keyAttack = reg("Oto vuruş aç/kapat (moblar)", GLFW.GLFW_KEY_J);
        keyPlay = reg("Müzik: oynat/durdur", GLFW.GLFW_KEY_KP_5);
        keyNext = reg("Müzik: sonraki şarkı", GLFW.GLFW_KEY_KP_6);
        keyPrev = reg("Müzik: önceki şarkı", GLFW.GLFW_KEY_KP_4);

        HudRenderCallback.EVENT.register((ctx, tickCounter) -> Hud.render(ctx));
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    }

    private KeyBinding reg(String name, int key) {
        return KeyBindingHelper.registerKeyBinding(
            new KeyBinding(name, InputUtil.Type.KEYSYM, key, "Trail Mod"));
    }

    private void tick(MinecraftClient mc) {
        Config c = Config.I;
        tickCount++;

        while (keySettings.wasPressed()) mc.setScreen(new SettingsScreen());
        while (keyEffect.wasPressed()) {
            c.effect = (c.effect + 1) % EFFECTS.length;
            Config.save();
            msg(mc, "Efekt: " + NAMES[c.effect]);
        }
        while (keyToggle.wasPressed()) {
            c.trail = !c.trail;
            Config.save();
            msg(mc, c.trail ? "İz açık" : "İz kapalı");
        }
        while (keyLock.wasPressed()) {
            if (Hud.lockedId != -1) {
                Hud.lockedId = -1;
                msg(mc, "Kilit bırakıldı");
            } else if (mc.targetedEntity instanceof LivingEntity le) {
                Hud.lockedId = le.getId();
                msg(mc, "Kilitlendi: " + le.getName().getString());
            } else {
                msg(mc, "Önce bir hedefe bak");
            }
        }

        while (keyAttack.wasPressed()) {
            c.autoAttack = !c.autoAttack;
            Config.save();
            msg(mc, c.autoAttack ? "Oto vuruş açık" : "Oto vuruş kapalı");
        }
        while (keyPlay.wasPressed()) mediaKey(mc, Media.PLAY_PAUSE, "Müzik: oynat/durdur");
        while (keyNext.wasPressed()) mediaKey(mc, Media.NEXT, "Müzik: sonraki şarkı");
        while (keyPrev.wasPressed()) mediaKey(mc, Media.PREV, "Müzik: önceki şarkı");

        if (mc.player == null || mc.world == null) return;
        var p = mc.player;
        HudElements.tick(mc);

        if (c.autoSprint && mc.options.forwardKey.isPressed() && !p.isSneaking()
            && !p.horizontalCollision && p.getHungerManager().getFoodLevel() > 6) {
            p.setSprinting(true);
        }

        // Havai fişek kombosu: fişek slotuna geç, kullan, kısa süre sonra silaha dön
        while (keyFirework.wasPressed()) {
            int fw = c.fireworkSlot - 1;
            ItemStack st = p.getInventory().getStack(fw);
            if (!st.isOf(Items.FIREWORK_ROCKET)) {
                msg(mc, c.fireworkSlot + ". slotta havai fişek yok");
            } else if (mc.interactionManager != null) {
                p.getInventory().selectedSlot = fw;
                mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
                p.swingHand(Hand.MAIN_HAND);
                returnTicks = 3;
            }
        }
        if (returnTicks > 0 && --returnTicks == 0) {
            p.getInventory().selectedSlot = c.weaponSlot - 1;
        }

        // Oto vuruş: sadece mob'lara, oyunculara asla vurmaz
        if (c.autoAttack && mc.currentScreen == null && mc.interactionManager != null
            && mc.targetedEntity instanceof LivingEntity le && le.isAlive()
            && !(le instanceof PlayerEntity)
            && (!c.hostileOnly || le instanceof Monster || le instanceof ArmorStandEntity)) {
            attackTimer++;
            boolean ready = !c.waitCooldown || p.getAttackCooldownProgress(0.5f) >= 1.0f;
            if (attackTimer >= c.attackDelay && ready) {
                mc.interactionManager.attackEntity(p, le);
                p.swingHand(Hand.MAIN_HAND);
                attackTimer = 0;
            }
        } else {
            attackTimer = 0;
        }

        // Parçacık izi
        if (c.trail) {
            double speed = p.getVelocity().horizontalLength();
            if (speed > 0.05 || !p.isOnGround()) {
                for (int i = 0; i < c.amount; i++) {
                    mc.world.addParticle(EFFECTS[c.effect % EFFECTS.length],
                        p.getX() + (Math.random() - 0.5) * 0.5,
                        p.getY() + 0.1 + Math.random() * 0.3,
                        p.getZ() + (Math.random() - 0.5) * 0.5,
                        0, 0.02, 0);
                }
            }
        }

        // Kilitli hedefin kafasının üstünde işaret
        if (c.lockMarker && Hud.lockedId != -1 && tickCount % 3 == 0) {
            var e = mc.world.getEntityById(Hud.lockedId);
            if (e != null) {
                mc.world.addParticle(ParticleTypes.END_ROD,
                    e.getX(), e.getY() + e.getHeight() + 0.5, e.getZ(), 0, 0, 0);
            }
        }
    }

    private void mediaKey(MinecraftClient mc, int code, String text) {
        if (!Media.supported()) { msg(mc, "Müzik tuşları sadece Windows'ta çalışır"); return; }
        Media.send(code);
        msg(mc, text);
    }

    private void msg(MinecraftClient mc, String text) {
        if (mc.player != null) mc.player.sendMessage(Text.literal(text), true);
    }
}
