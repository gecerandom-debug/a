package com.example.trail;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

import java.util.Map;

public class HudEditScreen extends Screen {
    private final Screen parent;
    private String dragging = null;
    private double offX, offY;

    public HudEditScreen(Screen parent) {
        super(Text.literal("HUD düzenle"));
        this.parent = parent;
    }

    private String hit(double mx, double my) {
        for (int i = HudElements.IDS.length - 1; i >= 0; i--) {
            float[] b = HudElements.bounds.get(HudElements.IDS[i]);
            if (b != null && mx >= b[0] && mx <= b[0] + b[2] && my >= b[1] && my <= b[1] + b[3]) {
                return HudElements.IDS[i];
            }
        }
        return null;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        String id = hit(mx, my);
        if (id != null) {
            if (button == 1) {
                var e = HudElements.elem(id);
                e.on = !e.on;
            } else {
                float[] b = HudElements.bounds.get(id);
                dragging = id;
                offX = mx - b[0];
                offY = my - b[1];
            }
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging != null) {
            var e = HudElements.elem(dragging);
            e.x = MathHelper.clamp((float) ((mx - offX) / width), 0f, 0.98f);
            e.y = MathHelper.clamp((float) ((my - offY) / height), 0f, 0.98f);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragging != null) {
            dragging = null;
            Config.save();
            return true;
        }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        String id = hit(mx, my);
        if (id != null) {
            var e = HudElements.elem(id);
            e.scale = MathHelper.clamp(e.scale + (float) vAmount * 0.1f, 0.5f, 3f);
            return true;
        }
        return super.mouseScrolled(mx, my, hAmount, vAmount);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        HudElements.renderAll(ctx, true);
        ctx.drawCenteredTextWithShadow(textRenderer,
            "Sürükle: taşı  |  Tekerlek: boyut  |  Sağ tık: aç/kapat  |  ESC: bitti",
            width / 2, height - 14, 0xFFFFFFFF);
    }

    @Override
    public void close() {
        Config.save();
        client.setScreen(parent);
    }
}
