package com.example.trail;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public class Config {
    public boolean trail = true;
    public int effect = 0;
    public int amount = 3;
    public boolean targetHud = true;
    public boolean lockMarker = true;
    public boolean musicHud = true;
    public int musicSeconds = 10;   // 0 = hep göster
    public int musicCorner = 1;     // 0 sol-üst, 1 sağ-üst, 2 sol-alt, 3 sağ-alt
    public int weaponSlot = 1;
    public int fireworkSlot = 9;
    public boolean coordsHud = true;
    public boolean autoSprint = false;
    public boolean autoAttack = false;
    public int attackDelay = 10;      // tick (20 tick = 1 sn)
    public boolean waitCooldown = true;
    public boolean hostileOnly = true;
    public boolean cooldownHud = true;
    public boolean cooldownOnlyTarget = true;

    // --- Görseller / HUD sistemi ---
    public static class Elem {
        public boolean on; public float x, y; public float scale = 1f;
        public Elem() {}
        public Elem(boolean on, float x, float y) { this.on = on; this.x = x; this.y = y; }
    }
    public java.util.Map<String, Elem> hud = new java.util.LinkedHashMap<>();
    public int themeMode = 1;          // 0 sabit, 1 rainbow, 2 gradient
    public int colorA = 0x55AAFF;
    public int colorB = 0xFF55AA;
    public int opacity = 150;          // panel opaklığı 0-255
    public boolean hitParticles = false;
    public int hitEffect = 8;
    public boolean chinaHat = false;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Path path() { return FabricLoader.getInstance().getConfigDir().resolve("trailmod.json"); }
    public static Config I = load();

    private static Config load() {
        try {
            Path p = path();
            if (Files.exists(p)) {
                Config c = GSON.fromJson(Files.readString(p), Config.class);
                if (c != null) return c;
            }
        } catch (Exception ignored) {}
        return new Config();
    }

    public static void save() {
        try { Files.writeString(path(), GSON.toJson(I)); } catch (Exception ignored) {}
    }
}
